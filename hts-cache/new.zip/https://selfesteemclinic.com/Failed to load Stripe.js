<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>404 Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      * {
        transition: all 0.6s;
      }

      html {
        height: 100%;
      }

      body {
        font-family: 'Lato', sans-serif;
        color: #888;
        margin: 0;
      }

      #main {
        display: table;
        width: 100%;
        height: 100vh;
        text-align: center;
      }

      .fof {
        display: table-cell;
        vertical-align: middle;
      }

      .fof h1 {
        font-size: 50px;
        display: inline-block;
        padding-right: 12px;
        animation: type 0.5s alternate infinite;
      }

      @keyframes type {
        from {
          box-shadow: inset -3px 0px 0px #888;
        }
        to {
          box-shadow: inset -3px 0px 0px transparent;
        }
      }
    </style>
  </head>
  <body>
    <div id="main">
      <div class="fof">
        <h1>Error 404</h1>
      </div>
    </div>
  <script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4bc70e2c01a94c73b74392e4234840661791215815920" integrity="sha512-L0ha0OXavK/8okipN9F8BtP84dg9DUhPERbBXzwI6dgTA55d2+yweo3pn5CSFYs45/r8md2+xvUPtTdvTNRfjA==" data-cf-beacon='{"version":"2024.11.0","token":"d56c0fb9091e40fc8f3829f8a67134fa","spa":2}' crossorigin="anonymous"></script>
</body>
</html>
